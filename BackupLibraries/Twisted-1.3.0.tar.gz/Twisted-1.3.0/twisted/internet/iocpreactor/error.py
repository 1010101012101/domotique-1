from twisted.internet.error import * # whoa, filthy, but beats monkeypatching

werrMapping = {
}

