from warnings import warn
warn('geopy.parsers is deprecated.', DeprecationWarning)

from geopy.parsers.base import Parser
